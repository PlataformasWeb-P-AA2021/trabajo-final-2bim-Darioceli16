/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete1;

import java.util.Scanner;
import paquete2.Propietario;
import paquete3.PlanPostPagoMegas;
import paquete3.PlanPostPagoMinutos;
import paquete3.PlanPostPagoMinutosMegas;
import paquete3.PlanPostPagoMinutosMegasEconomico;

/**
 *
 * @author Smart
 */
public class Principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Declarar variables
        String nombreArchivo = ("Planes.txt");
        short n, opcion;
        String nom, ape, id;
        // Entrada de datos
        System.out.print("\t<< PLAN CELULAR>>\n");
        System.out.println("\t===========================\n");
        System.out.print("\t<< BASE DE DATOS>>\n");
        System.out.println("\t===========================\n");
        System.out.print("Ingrese su nombre: ");
        nom = sc.nextLine();
        System.out.print("Ingrese su apellido: ");
        ape = sc.nextLine();
        System.out.print("Ingrese su identificacion: ");
        id = sc.nextLine();
        System.out.print("QUE TIPO DE PLAN DESEA ADQUIRIR: ");
        n = sc.nextShort();
        Propietario pro1 = new Propietario(nom, id, ape);
        do {
            System.out.print("\nMenu: \n"
                    + "Digite el numero de el proceso que desea realizar\n"
                    + "1 - PLAN POST PAGO MINUTOS\\n\"\n"
                    + "2 - PLAN POST PAGO MEGAS\\n\"\n"
                    + "3 - PLAN POST PAGO MINUTOS MEGAS\"\n"
                    + "4 - PLAN POST PAGO MINUTOS MEGAS ECONOMICO\"\n"
                    + "5 - SALIR\"\n"
                    + "6 - REGRESAR (volver a escojer)"
                    + "Opcion: ");
            opcion = sc.nextShort();

            switch (opcion) {
                case 1:
                    double nuM,
                     nuI;
                    double preM,
                     preI,p;
                    System.out.print("\t<< PLAN POST PAGO MINUTOS >>\n");
                    System.out.println("\t===========================\n");
                    System.out.print("Ingrese el numero de minutos nacionales: ");
                    nuM = sc.nextDouble();
                    System.out.print("Ingrese el precio por minuto nacional: ");
                    preM = sc.nextDouble();
                    System.out.print("Ingrese el numero de minutos internacionales: ");
                    nuI = sc.nextDouble();
                    System.out.print("Ingrese el precio de minutos internacionales: ");
                    preI = sc.nextDouble();
                    //establecer variables
                    PlanPostPagoMinutos ca1 = new PlanPostPagoMinutos(nuM, preM, nuI, preI);

                    System.out.print("\nNombre: " + pro1.obtenerNombres()
                            + "\nApellido: " + pro1.obtenerApellido()
                            + "\nIdentificacion: " + pro1.obtenerCedula()
                            + "\nNumero de minutos nacionales: " + ca1.obtenerMinutosN()
                            + "\nPrecio por minuto nacional: " + ca1.obtenerCostoN()
                            + "\nNumero de minutos internacionales: " + ca1.obtenerMinutosI()
                            + "\nPrecio por minuto internacional: " + ca1.obtenerCostoI()
                            + "\nCosto final: " + ca1.obtenerCostoFinal());

                    break;
                case 2:
                    System.out.print("\t<< PLAN POST PAGO MEGAS >>\n");
                    System.out.println("\t===========================\n");
                    System.out.print("Ingrese el numero de megas expresado en gigas: ");
                    nuM = sc.nextDouble();
                    System.out.print("Ingrese el precio por cada giga: ");
                    preM = sc.nextDouble();
                    System.out.print("Ingrese la tarifa base: ");
                    nuI = sc.nextDouble();
                    //establecer variables
                    PlanPostPagoMegas ca = new PlanPostPagoMegas(nuM, preM, nuI);

                    System.out.print("\nNombre: " + pro1.obtenerNombres()
                            + "\nApellido: " + pro1.obtenerApellido()
                            + "\nIdentificacion: " + pro1.obtenerCedula()
                            + "\nNumero de megas expresado en gigas: " + ca.obtenerMinutosI()
                            + "\nPrecio por cada giga: " + ca.obtenerCostoI()
                            + "\nLa tarifa base: " + ca.obtenerTarifa()
                            + "\nCosto final: " + depar1.obtenerCostoFinalD());
                    break;
                case 3:
                    System.out.print("\t<< PLAN POST PAGO MINUTOS MEGAS >>\n");
                    System.out.println("\t===========================\n");
                    System.out.print("Ingrese el numero de minutos: ");
                    nuM = sc.nextDouble();
                    System.out.print("Ingrese el precio por minuto: ");
                    preM = sc.nextDouble();
                    System.out.print("Ingrese el precio por cada giga: ");
                    preI = sc.nextDouble();
                    System.out.print("Ingrese El precio por giga: ");
                    nuI = sc.nextDouble();
                    //establecer variables
                    PlanPostPagoMinutosMegas c = new PlanPostPagoMinutosMegas(nuM, preM, nuI, preI);
                    //presentar datos
                    System.out.print("\nNombre: " + pro1.obtenerNombres()
                            + "\nApellido: " + pro1.obtenerApellido()
                            + "\nIdentificacion: " + pro1.obtenerCedula()
                            + "\nNumero de minutos Nacionles: " + c.obtenerMinutosN()
                            + "\nPrecio por minuto: " + c.obtenerCostoN()
                            + "\nNumero de megas expresado en gigas: " + c.obtenerMega()
                            + "\nPrecio por cada giga: " + c.obtenerCostoI()
                            + "\nCosto final: " + ca1.obtenerCostoFinal());

                    break;
                case 4:

                    System.out.print("\t<< PLAN POST PAGO MINUTOS MEGAS ECONOMICO >>\n");
                    System.out.println("\t===========================\n");
                    System.out.print("Ingrese el numero de minutos : ");
                    nuM = sc.nextDouble();
                    System.out.print("Ingrese el precio por minuto : ");
                    preM = sc.nextDouble();
                    System.out.print("Ingrese el precio por cada giga: ");
                    preI = sc.nextDouble();
                    System.out.print("Ingrese la tarifa base: ");
                    nuI = sc.nextDouble();
                    System.out.print("Ingrese el porcentaje de descuento: ");
                    p = sc.nextDouble();
                    //establecer variables
                    PlanPostPagoMinutosMegasEconomico e = new PlanPostPagoMinutosMegasEconomico(nuM, preM, nuI, preI, p);
                    //presentar datos
                    System.out.print("\nNombre: " + pro1.obtenerNombres()
                            + "\nApellido: " + pro1.obtenerApellido()
                            + "\nIdentificacion: " + pro1.obtenerCedula()
                            + "\nNumero de minutos Nacionles: " + e.obtenerMinutosN()
                            + "\nPrecio por minuto: " + e.obtenerCostoN()
                            + "\nNumero de megas expresado en gigas: " + e.obtenerMega()
                            + "\nPrecio por cada giga: " + e.obtenerCostoI()
                            + "\nPorcentaje: " + e.obtenerPorcentaje()
                            + "\nCosto final: " + ca1.obtenerCostoFinal());

                    break;

                case 5:
                    System.out.println("GRACIAS POR SU COLABORACION");
                    break;
                case 6:
                    lis.VaciarListaNodo();
                    break;
                default:
                    System.err.println("Opcion Invalida");
            }
        } while (opcion != 7);

    }
}
