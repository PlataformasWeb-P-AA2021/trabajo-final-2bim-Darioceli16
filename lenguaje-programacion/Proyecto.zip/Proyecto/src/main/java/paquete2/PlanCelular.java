/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete2;

/**
 *
 * @author Smart
 */
public class PlanCelular {

    protected String ciudad;
    protected String marca;
    protected String modelo;
    protected String numero;
    protected double pago;

    public PlanCelular(String c, String m, String mo, String n,double p) {
        ciudad = c;
        marca = m;
        modelo = mo;
        numero = n;
        pago = p;
    }

    public void establecerCiudad(String e) {
        ciudad = e;
    }

    public void establecerMarca(String e) {
        marca = e;
    }

    public void establecerModelo(String e) {
        modelo = e;
    }

    public void establecerNumero(String e) {
        numero = e;
    }

    public void establecerPago(double e) {
        pago = e;
    }

    public String obtenerCiudad() {
        return ciudad;
    }

    public String obtenerMarca() {
        return marca;
    }

    public String obtenerModelo() {
        return modelo;
    }

    public String obtenerNumero() {
        return numero;
    }

    public double obtenerPago() {
        return pago;
    }

    @Override
    public String toString() {
        String cadena = "DATOS DEL CELULAR";
        cadena = String.format("Nombre de la ciudad: %s\nMarca de celular: "
                + "%s\nModelo del celular: %s\nNumero celular: %f\nPago mensual",
                obtenerCiudad(), obtenerMarca(), obtenerModelo(),
                obtenerNumero(),obtenerPago());
        return cadena;

    }

}
