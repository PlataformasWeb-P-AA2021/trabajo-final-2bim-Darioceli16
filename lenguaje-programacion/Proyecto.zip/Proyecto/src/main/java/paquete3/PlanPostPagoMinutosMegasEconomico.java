/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete3;

/**
 *
 * @author Smart
 */
public class PlanPostPagoMinutosMegasEconomico {
    
    protected double minutosN;
    protected double costoN;
    protected double mega;
    protected double costoI;
    protected double porcentaje;

    public PlanPostPagoMinutosMegasEconomico(double mN, double cN, double mI, double cI, double p) {
        minutosN = mN;
        costoN = cN;
        mega = mI;
        costoI = cI;
        porcentaje = p;
    }

    public void establecerMinutosN(double e) {
        minutosN = e;
    }

    public void establecerCostoN(double e) {
        costoN = e;
    }

    public void establecerMinutosI(double e) {
        mega = e;
    }

    public void establecerCostoI(double e) {
        costoI = e;
    }

    public void establecerPorcentaje(double e) {
        porcentaje = e;
    }

    public double obtenerMinutosN() {
        return minutosN;
    }

    public double obtenerCostoN() {
        return costoN;
    }

    public double obtenerMega() {
        return mega;
    }

    public double obtenerCostoI() {
        return costoI;
    }

    public double obtenerPorcentaje() {
        return porcentaje;
    }

    @Override
    public String toString() {
        String cadena = "DATOS DEL CELULAR";
        cadena = String.format("Minutos nacionales: %s\nCosto Minuto nacional: "
                + "%s\nMinutos internacionales: %s\nCosto minuto internacional: %f\nPago mensual",
                obtenerMinutosN(), obtenerCostoN(), obtenerMega(),
                obtenerCostoI());
        return cadena;

    }
}


