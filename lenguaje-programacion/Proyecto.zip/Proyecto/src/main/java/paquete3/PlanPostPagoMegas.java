/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete3;

/**
 *
 * @author Smart
 */
public class PlanPostPagoMegas {
    protected double tarifa;
    protected double minutosI;
    protected double costoI;

    public PlanPostPagoMegas(double cN,double mI,double cI) {
        
        tarifa = cN;
        minutosI = mI;
        costoI = cI;
    }

    public void establecerTarifa(double e) {
        tarifa = e;
    }

    public void establecerMinutosI(double e) {
        minutosI = e;
    }
    public void establecerCostoI(double e) {
        costoI = e;
    }

    public double obtenerTarifa() {
        return tarifa;
    }

    public double obtenerMinutosI() {
        return minutosI;
    }

    public double obtenerCostoI() {
        return costoI;
    }

    @Override
    public String toString() {
        String cadena = "DATOS DEL CELULAR";
        cadena = String.format("Tarifa base: "
                + "%s\nMinutos internacionales: %s\nCosto minuto internacional: %f\nPago mensual",
                obtenerTarifa(), obtenerMinutosI(),
                obtenerCostoI());
        return cadena;

    } 
}
