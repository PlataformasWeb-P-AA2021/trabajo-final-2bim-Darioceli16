/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete3;

/**
 *
 * @author Smart
 */
public class PlanPostPagoMinutos {
     protected double minutosN;
    protected double costoN;
    protected double minutosI;
    protected double costoI;

    public PlanPostPagoMinutos(double mN,double cN,double mI,double cI) {
        minutosN = mN;
        costoN = cN;
        minutosI = mI;
        costoI = cI;
    }

    public void establecerMinutosN(double e) {
        minutosN = e;
    }

    public void establecerCostoN(double e) {
        costoN = e;
    }

    public void establecerMinutosI(double e) {
        minutosI = e;
    }
    public void establecerCostoI(double e) {
        costoI = e;
    }

    public double obtenerMinutosN() {
        return minutosN;
    }

    public double obtenerCostoN() {
        return costoN;
    }

    public double obtenerMinutosI() {
        return minutosI;
    }

    public double obtenerCostoI() {
        return costoI;
    }

    @Override
    public String toString() {
        String cadena = "DATOS DEL CELULAR";
        cadena = String.format("Minutos nacionales: %s\nCosto Minuto nacional: "
                + "%s\nMinutos internacionales: %s\nCosto minuto internacional: %f\nPago mensual",
                obtenerMinutosN(), obtenerCostoN(), obtenerMinutosI(),
                obtenerCostoI());
        return cadena;

    }
}
